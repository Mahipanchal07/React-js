import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function Electronic() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/products/category/electronics')
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  return (
    <div>
      <h2>Electronic</h2>
      <div>
        {products.map((el) => (
          <div key={el.id}>
            <Link to={`/ProductDetail/${el.id}`}>{el.title}</Link>
            <p>Price: ${el.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
