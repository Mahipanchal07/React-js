import React from 'react'
import { Link ,Outlet } from 'react-router-dom'

export default function Product() {
  return (
    <div style={{display:'flex'}}>
        <div>
        <Link to="electronic"> Electronic</Link>
        <Link to=""> Cloth</Link>
        </div>
        <div>
            <Outlet/>  
        </div>
    </div>
   
  )
}