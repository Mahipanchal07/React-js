// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC46N0I5LuOULAIH4oBUkySQwpWzGearCY",
  authDomain: "signup-14182.firebaseapp.com",
  projectId: "signup-14182",
  storageBucket: "signup-14182.firebasestorage.app",
  messagingSenderId: "999451774931",
  appId: "1:999451774931:web:d2c70a0d06a95670ace926",
  measurementId: "G-5PSWSSQFE0"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);