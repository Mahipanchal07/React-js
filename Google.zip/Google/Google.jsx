import React from 'react'
import { useState } from 'react'
import {  signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { getAuth } from "firebase/auth";
import { app } from './Firebase';



const auth = getAuth();

export default function Google() {
    const [url,seturl] = useState("");
    const provider = new GoogleAuthProvider();

    function register(e){
        e.preventDefault();
        signInWithPopup(auth, provider)
        .then((result) => {
          const credential = GoogleAuthProvider.credentialFromResult(result);
          const token = credential.accessToken;
          const user = result.user;
          console.log(user);
        }).catch((error) => {
          const email = error.customData.email;
          const credential = GoogleAuthProvider.credentialFromError(error);
        });
    } 
  return (
    <div>

            <h1>Sign in With Google</h1>

            <button onClick={register}>SignIn</button> <br />
        </div>
        
  )
}
