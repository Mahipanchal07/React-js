import React from 'react'
import { getAuth,signInWithEmailAndPassword } from "firebase/auth";
import { app } from './Firebase';
import { useState } from 'react'



const auth = getAuth(app);

export default function Signin() {


    const [email, setemail] = useState("");
    const [password, setPassword] = useState("");


    function register() {
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                alert('success')
            })
            .catch((error) => {
                alert('Enter Valid Informations');
            });
    }

    return (
        <div>


            <h1>Register</h1>
            <input type="text" value={email} name='email' onChange={(e) => { setemail(e.target.value) }} />
            <input type="text" value={password} name='password' onChange={(e) => { setPassword(e.target.value) }} />
            <button onClick={register}>SignIn</button>


        </div>
    )
}