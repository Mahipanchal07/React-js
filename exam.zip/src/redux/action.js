import axios from 'axios';

export const FETCH_RECIPES = 'FETCH_RECIPES';
export const ADD_RECIPE = 'ADD_RECIPE';
export const UPDATE_RECIPE = 'UPDATE_RECIPE';
export const DELETE_RECIPE = 'DELETE_RECIPE';

// Action creators
export const fetchRecipes = (recipes) => ({ type: FETCH_RECIPES, payload: recipes });
export const addRecipe = (recipe) => ({ type: ADD_RECIPE, payload: recipe });
export const updateRecipe = (recipe) => ({ type: UPDATE_RECIPE, payload: recipe });
export const deleteRecipe = (id) => ({ type: DELETE_RECIPE, payload: id });

// Thunks
const API_URL = 'http://localhost:3000/recipes';

export const fetchRecipesThunk = () => async (dispatch) => {
    try {
        const response = await axios.get(API_URL);
        dispatch(fetchRecipes(response.data));
    } catch (error) {
        console.error('Error fetching recipes:', error);
    }
};

export const addRecipeThunk = (recipe) => async (dispatch) => {
    try {
        const response = await axios.post(API_URL, recipe);
        dispatch(addRecipe(response.data));
    } catch (error) {
        console.error('Error adding recipe:', error);
    }
};

// action.js
export const updateRecipeThunk = (id, updatedRecipe) => async (dispatch) => {
    try {
        const response = await axios.put(`http://localhost:3000/recipes/${id}`, updatedRecipe);
        dispatch(updateRecipe(response.data)); // Dispatch action to update state
    } catch (error) {
        console.error('Error updating recipe:', error);
    }
};


// action.js
export const deleteRecipeThunk = (id) => async (dispatch) => {
    try {
        await axios.delete(`http://localhost:3000/recipes/${id}`);
        dispatch(deleteRecipe(id)); // This action will update the state
    } catch (error) {
        console.error('Error deleting recipe:', error);
    }
};
;
