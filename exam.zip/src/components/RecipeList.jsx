import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRecipesThunk } from '../redux/action';
import RecipeDetails from './RecipeDetails';
import './RecipeList.css'; // Import the CSS file

const RecipeList = () => {
    const dispatch = useDispatch();
    const recipes = useSelector((state) => state.recipe.recipes);

    useEffect(() => {
        dispatch(fetchRecipesThunk());
    }, [dispatch]);

    return (
        <div className="recipe-list-container">
            <h2>Recipe List</h2>
            <div className="recipe-list">
                {recipes.length === 0 ? (
                    <p>No recipes available</p>
                ) : (
                    recipes.map((recipe) => (
                        <RecipeDetails key={recipe.id} recipe={recipe} />
                    ))
                )}
            </div>
        </div>
    );
};

export default RecipeList;
